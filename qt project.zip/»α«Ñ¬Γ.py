import sys
import sqlite3
import random
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QMainWindow, QTableWidgetItem
from PyQt5.QtWidgets import QLineEdit, QInputDialog, QLabel, QDialog, QPlainTextEdit
from PyQt5.QtGui import QPixmap
from PyQt5 import uic
from functools import partial


class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setGeometry(300, 50, 800, 700)
        self.setWindowTitle('Своя игра')
        self.col, ok_pressed = QInputDialog.getInt(
            self, "Количество игроков", "Сколько человек играет?",
            2, 2, 3, 1)
        self.name = []
        for i in range(1, self.col + 1):
            name, ok_pressed = QInputDialog.getText(self, "Введите имя",
                                                            "имя игрока " + str(i))
            self.name.append(name)
        self.explanations = QLabel('R - правила', self)
        self.explanations.resize(100, 60)
        self.explanations.move(700, 0)
        self.column1 = QLabel(self)
        self.column1.resize(130, 60)
        self.column1.move(20, 70)
        self.column1.setText('традиции')
        for i in range(1, 4):
            self.push1 = QPushButton(str(i*100), self)
            self.push1.resize(130, 60)
            self.push1.move(20 + (130 * i) + 10, 70)
            self.push1.clicked.connect(self.lbl1)
        self.column2 = QLabel(self)
        self.column2.resize(130, 60)
        self.column2.move(20, 140)
        self.column2.setText('Известные личности')
        for i in range(1, 4):
            self.push2 = QPushButton(str(i * 100), self)
            self.push2.resize(130, 60)
            self.push2.move(20 + (130 * i) + 10, 140)
            self.push2.clicked.connect(self.lbl2)
        self.column3 = QLabel(self)
        self.column3.resize(130, 60)
        self.column3.move(20, 210)
        self.column3.setText('еда')
        for i in range(1, 4):
            self.push3 = QPushButton(str(i * 100), self)
            self.push3.resize(130, 60)
            self.push3.move(20 + (130 * i) + 10, 210)
            self.push3.clicked.connect(self.lbl3)
        self.column4 = QLabel(self)
        self.column4.resize(130, 60)
        self.column4.move(20, 280)
        self.column4.setText('история')
        for i in range(1, 4):
            self.push4 = QPushButton(str(i * 100), self)
            self.push4.resize(130, 60)
            self.push4.move(20 + (130 * i) + 10, 280)
            self.push4.clicked.connect(self.lbl4)
        self.column5 = QLabel(self)
        self.column5.resize(130, 60)
        self.column5.move(20, 350)
        self.column5.setText('музеи')
        for i in range(1, 4):
            self.push5 = QPushButton(str(i * 100), self)
            self.push5.resize(130, 60)
            self.push5.move(20 + (130 * i) + 10, 350)
            self.push5.clicked.connect(self.lbl5)
        self.column6 = QLabel(self)
        self.column6.resize(130, 60)
        self.column6.move(20, 420)
        self.column6.setText('достопримечательности')
        for i in range(1, 4):
            self.push6 = QPushButton(str(i * 100), self)
            self.push6.resize(130, 60)
            self.push6.move(20 + (130 * i) + 10, 420)
            self.push6.clicked.connect(self.lbl6)
        self.column7 = QLabel(self)
        self.column7.resize(130, 60)
        self.column7.move(20, 490)
        self.column7.setText('кот в мешке')
        for i in range(1, 4):
            self.push7 = QPushButton(str(i * 100), self)
            self.push7.resize(130, 60)
            self.push7.move(20 + (130 * i) + 10, 490)
            self.push7.clicked.connect(self.lbl7)
        self.labelplayer1 = QLabel(self.name[0], self)
        self.labelplayer1.resize(130, 60)
        self.labelplayer1.move(20, 560)
        self.labelplayer2 = QLabel(self.name[1], self)
        self.labelplayer2.resize(130, 60)
        self.labelplayer2.move(160, 560)
        if self.col == 3:
            self.labelplayer3 = QLabel(self.name[2], self)
            self.labelplayer3.resize(130, 60)
            self.labelplayer3.move(290, 560)
        con = sqlite3.connect('табблкп.db')
        self.cur = con.cursor()
        self.colmove = 0
        self.scores = [0] * self.col
        self.pushstatistics = QPushButton('статитика', self)
        self.pushstatistics.resize(80, 60)
        self.pushstatistics.move(380, 600)
        self.pushstatistics.clicked.connect(self.statistic)
        self.pushwin = QPushButton('конец игры', self)
        self.pushwin.resize(80, 60)
        self.pushwin.move(450, 600)
        self.pushwin.clicked.connect(partial(self.gameover, [300, 150, 0]))
        self.rulesOpen = Rules()

    def lbl1(self):
        sender = (self.sender()).text()
        qw = self.cur.execute("""SELECT * FROM вопросики 
                    WHERE категория == 'традиции' AND уровень = ?""", (sender, )).fetchall()
        n = random.choice(range(len(qw)))
        for i in range(self.col):
            qves, ok_pressed = QInputDialog.getItem(
                self, "Отвечает игрок" + str(i + 1), qw[n][0],
                (qw[n][1], qw[n][4], qw[n][5]), 1, False)
            if ok_pressed is True:
                if qves == qw[n][1]:
                    self.scores[i] += int(sender)
                    break
        self.sender().hide()
        self.colmove += 1
        self.labelplayer1.setText(self.name[0] + '\n' + str(self.scores[0]))
        self.labelplayer2.setText(self.name[1] + '\n' + str(self.scores[1]))
        if self.col == 3:
            self.labelplayer3.setText(self.name[2] + '\n' + str(self.scores[2]))
        if self.colmove == 21:
            self.gameover(self.scores)

    def lbl2(self):
        sender = (self.sender()).text()
        qw = self.cur.execute("""SELECT * FROM вопросики
                    WHERE категория == 'известные личности' AND уровень = ?""", (sender, )).fetchall()
        n = random.choice(range(len(qw)))
        for i in range(self.col):
            qves, ok_pressed = QInputDialog.getItem(
                self, "Отвечает игрок" + str(i + 1), qw[n][0],
                (qw[n][1], qw[n][4], qw[n][5]), 1, False)
            if ok_pressed is True:
                if qves == qw[n][1]:
                    self.scores[i] += int(sender)
                    break
        self.sender().hide()
        self.colmove += 1
        self.labelplayer1.setText(self.name[0] + '\n' + str(self.scores[0]))
        self.labelplayer2.setText(self.name[1] + '\n' + str(self.scores[1]))
        if self.col == 3:
            self.labelplayer3.setText(self.name[2] + '\n' + str(self.scores[2]))
        if self.colmove == 21:
            self.gameover(self.scores)
            
    def lbl3(self):
        sender = (self.sender()).text()
        qw = self.cur.execute("""SELECT * FROM вопросики
                    WHERE категория == 'еда' AND уровень = ?""", (sender, )).fetchall()
        n = random.choice(range(len(qw)))
        for i in range(self.col):
            qves, ok_pressed = QInputDialog.getItem(
                self, "Отвечает игрок" + str(i + 1), qw[n][0],
                (qw[n][1], qw[n][4], qw[n][5]), 1, False)
            if ok_pressed is True:
                if qves == qw[n][1]:
                    self.scores[i] += int(sender)
                    break
        self.sender().hide()
        self.colmove += 1
        self.labelplayer1.setText(self.name[0] + '\n' + str(self.scores[0]))
        self.labelplayer2.setText(self.name[1] + '\n' + str(self.scores[1]))
        if self.col == 3:
            self.labelplayer3.setText(self.name[2] + '\n' + str(self.scores[2]))
        if self.colmove == 21:
            self.gameover(self.scores)

    def lbl4(self):
        sender = (self.sender()).text()
        qw = self.cur.execute("""SELECT * FROM вопросики
                    WHERE категория == 'история' AND уровень = ?""", (sender, )).fetchall()
        n = random.choice(range(len(qw)))
        for i in range(self.col):
            qves, ok_pressed = QInputDialog.getItem(
                self, "Отвечает игрок" + str(i + 1), qw[n][0],
                (qw[n][1], qw[n][4], qw[n][5]), 1, False)
            if ok_pressed is True:
                if qves == qw[n][1]:
                    self.scores[i] += int(sender)
                    break
        self.sender().hide()
        self.colmove += 1
        self.labelplayer1.setText(self.name[0] + '\n' + str(self.scores[0]))
        self.labelplayer2.setText(self.name[1] + '\n' + str(self.scores[1]))
        if self.col == 3:
            self.labelplayer3.setText(self.name[2] + '\n' + str(self.scores[2]))
        if self.colmove == 21:
            self.gameover(self.scores)

    def lbl5(self):
        sender = (self.sender()).text()
        qw = self.cur.execute("""SELECT * FROM вопросики
                    WHERE категория == 'музеи' AND уровень = ?""", (sender, )).fetchall()
        n = random.choice(range(len(qw)))
        for i in range(self.col):
            qves, ok_pressed = QInputDialog.getItem(
                self, "Отвечает игрок" + str(i + 1), qw[n][0],
                (qw[n][1], qw[n][4], qw[n][5]), 1, False)
            if ok_pressed is True:
                if qves == qw[n][1]:
                    self.scores[i] += int(sender)
                    break
        self.sender().hide()
        self.colmove += 1
        self.labelplayer1.setText(self.name[0] + '\n' + str(self.scores[0]))
        self.labelplayer2.setText(self.name[1] + '\n' + str(self.scores[1]))
        if self.col == 3:
            self.labelplayer3.setText(self.name[2] + '\n' + str(self.scores[2]))
        if self.colmove == 21:
            self.gameover(self.scores)

    def lbl6(self):
        sender = (self.sender()).text()
        qw = self.cur.execute("""SELECT * FROM вопросики
                    WHERE категория == 'достопримечательности' AND уровень = ?""", (sender, )).fetchall()
        n = random.choice(range(len(qw)))
        for i in range(self.col):
            qves, ok_pressed = QInputDialog.getItem(
                self, "Отвечает игрок" + str(i + 1), qw[n][0],
                (qw[n][1], qw[n][4], qw[n][5]), 1, False)
            if ok_pressed is True:
                if qves == qw[n][1]:
                    self.scores[i] += int(sender)
                    break
        self.sender().hide()
        self.colmove += 1
        self.labelplayer1.setText(self.name[0] + '\n' + str(self.scores[0]))
        self.labelplayer2.setText(self.name[1] + '\n' + str(self.scores[1]))
        if self.col == 3:
            self.labelplayer3.setText(self.name[2] + '\n' + str(self.scores[2]))
        if self.colmove == 21:
            self.gameover(self.scores)

    def lbl7(self):
        sender = (self.sender()).text()
        qw = self.cur.execute("""SELECT * FROM вопросики 
                    WHERE категория == 'кот в мешке' AND уровень = ?""", (sender, )).fetchall()
        n = random.choice(range(len(qw)))
        for i in range(self.col):
            qves, ok_pressed = QInputDialog.getItem(
                self, "Отвечает игрок" + str(i + 1), qw[n][0],
                (qw[n][1], qw[n][4], qw[n][5]), 1, False)
            if ok_pressed is True:
                if qves == qw[n][1]:
                    self.scores[i] += int(sender)
                    break
        self.sender().hide()
        self.colmove += 1
        self.labelplayer1.setText(self.name[0] + '\n' + str(self.scores[0]))
        self.labelplayer2.setText(self.name[1] + '\n' + str(self.scores[1]))
        if self.col == 3:
            self.labelplayer3.setText(self.name[2] + '\n' + str(self.scores[2]))
        if self.colmove == 21:
            self.gameover(self.scores)

    def statistic(self):
        self.st = statistics()
        self.st.show()

    def gameover(self, player):
        if player.count(max(player)) == self.col:
            name = 'ничья'
            point = 0
        elif player.count(max(player)) != 1:
            player.index(max(player))
            point = max(player)
            name = self.name[player.index(max(player))]
            del player[player.index(max(player))]
            del self.name[player.index(max(player))]
            player.index(max(player))
            name += '-' + self.name[player.index(max(player))]
        else:
            point = max(player)
            name = self.name[player.index(max(player))]            
        self.con = sqlite3.connect("статистика.db")
        cur = self.con.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS allplays(No INTEGER PRIMARY KEY,
        score INT, name TEXT);""")
        cur.execute("INSERT INTO allplays(name, score) VALUES(?, ?)", (name, point))
        self.con.commit()
        self.end = winOpen(name, point)
        self.end.show()
        
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_R:
            self.rules()

    def rules(self):
        self.rulesOpen.show()

        
class Rules(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setGeometry(300, 50, 600, 400)
        self.setWindowTitle('правила')
        self.rules = QLabel(self)
        self.rules.resize(600, 400)
        self.rules.move(20, 0)
        f = open('rules.txt', 'r')
        t = f.read()
        f.close()
        self.rules.setText(t)


class winOpen(QWidget):
    def __init__(self, whowin, winscore):
        super().__init__()
        self.winscore = winscore
        self.whowin = whowin
        self.initUI()

    def initUI(self):
        self.setGeometry(300, 50, 900, 600)
        self.setWindowTitle('конец игры')
        self.winner = QLabel(self)
        self.winner.resize(200, 60)
        self.winner.move(20, 20)
        self.winner.setText('Выиграл игрок:' + ' ' + str(self.whowin))
        self.image = QLabel(self)
        self.image.move(20, 70)
        self.image.resize(800, 420)
        self.pixmap = QPixmap('unnamed.jpg')
        self.image.setPixmap(self.pixmap)

class statistics(QWidget):
    def __init__(self):
        super().__init__()
        uic.loadUi('статистика.ui', self)
        self.pushButton.clicked.connect(self.select_data)
        self.con = sqlite3.connect("статистика.db")
        cur = self.con.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS allplays(No INTEGER PRIMARY KEY,
        score INT, name TEXT);""")
        self.con.commit()

    def select_data(self):
        res = self.con.cursor().execute("""SELECT * FROM allplays ORDER BY No DESC""").fetchall()
        if len(res) > 0:
            self.tableWidget.setColumnCount(len(res[0]))
            self.tableWidget.setRowCount(len(res))
            for i, row in enumerate(res):
                for j, elem in enumerate(row):
                    self.tableWidget.setItem(
                        i, j, QTableWidgetItem(str(elem)))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Main()
    ex.show()
    sys.exit(app.exec())
